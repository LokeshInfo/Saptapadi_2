package com.ics.saptapadi;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.github.clans.fab.FloatingActionButton;

public class ContactActivity extends AppCompatActivity {
    FloatingActionButton fab;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

    }
}
