package com.ics.saptapadi.View_One;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.ics.saptapadi.R;

public class TearmAndConditionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tearm_and_condition);
    }
}
